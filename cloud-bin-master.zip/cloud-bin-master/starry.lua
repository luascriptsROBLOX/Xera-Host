loadstring(game:HttpGet("https://github.com/hello-n-bye/starry/blob/main/main.lua?raw=true", true))()
